from django.db import models
from django.contrib.auth.models import User


class Category(models.Model):
    name=models.CharField(max_length=100,verbose_name='Nombre')
    description=models.CharField(max_length=250,verbose_name='Descripcion')
    created_at=models.DateTimeField(auto_now=True, verbose_name='Creado el')

    class Meta:
        verbose_name="Categoría"
        verbose_name_plural="Categorías"

    def __str__(self):
        return self.name
    
# class Article(models.Model):
#     title=models.CharField(_(""), max_length=50)
